import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-circulo-de-datos-bluetooth-component',
  templateUrl: './circulo-de-datos-bluetooth-component.component.html',
  styleUrls: ['./circulo-de-datos-bluetooth-component.component.scss'],
})
export class CirculoDeDatosBluetoothComponentComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
