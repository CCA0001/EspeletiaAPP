import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-encabezado-app-movil-espeletia-component',
  templateUrl: './encabezado-app-movil-espeletia-component.component.html',
  styleUrls: ['./encabezado-app-movil-espeletia-component.component.scss'],
})
export class EncabezadoAppMovilEspeletiaComponentComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
