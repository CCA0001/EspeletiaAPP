import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-desplegable-component',
  templateUrl: './menu-desplegable-component.component.html',
  styleUrls: ['./menu-desplegable-component.component.scss'],
})
export class MenuDesplegableComponentComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
